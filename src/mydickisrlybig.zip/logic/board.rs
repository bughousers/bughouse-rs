use std::fmt;

#[derive(Clone, Copy)]
enum Piece {
    P,R,N,B,Q,K,E,
    p,r,n,b,q,k,e,
}

impl fmt::Display for Piece {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Piece::P => write!(f, "P"),
            Piece::R => write!(f, "R"),
            Piece::N => write!(f, "N"),
            Piece::B => write!(f, "B"),
            Piece::Q => write!(f, "Q"),
            Piece::K => write!(f, "K"),
            Piece::E => write!(f, " "),
            //_ => write!(f, "shouldn't happen")
        }
    }
}

pub struct ChessBoard {
    board: [[Piece; 8]; 8],
}


impl ChessBoard {

    pub fn new() -> ChessBoard {
        let arr = get_init_array();
        ChessBoard {
            board: arr,
        }
        
    }

    pub fn move_piece(&mut self,old_i: usize, old_j: usize, i:usize, j:usize) {
        self.board[i][j] = self.board[old_i][old_j];
        //println!("{}",self.board[i][j]);
        self.board[old_i][old_j] = Piece::E;
    }


    pub fn print_board(&self) {
        for i in 0..8 {
            for j in 0..8 {
                print!("[{}]",self.board[i][j]);
            }
            println!("");
        }
        
    }

}

fn get_init_array() -> [[Piece; 8]; 8] {
    let mut arr = [[Piece::E; 8]; 8];
    for i in 0..8 {
        arr[1][i] = Piece::P;
        arr[6][i] = Piece::P;
    }

    let indices: [usize;2] = [0,7];
    for i in 0..2 {
        //println!("{}", i);
        arr[indices[i]][0] = Piece::R;
        arr[indices[i]][1] = Piece::N;
        arr[indices[i]][2] = Piece::B;
        arr[indices[i]][3] = Piece::Q;
        arr[indices[i]][4] = Piece::K;
        arr[indices[i]][5] = Piece::B;
        arr[indices[i]][6] = Piece::N;
        arr[indices[i]][7] = Piece::R;
    }
    
    arr
}




