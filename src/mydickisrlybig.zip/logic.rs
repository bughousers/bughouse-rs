mod board;
use crate::logic::board::ChessBoard;


pub struct ChessLogic {
    chess_board: ChessBoard,
}

impl ChessLogic {
    pub fn print(&self){
        self.chess_board.print_board();
    }

    pub fn new() -> ChessLogic {
        ChessLogic{
            chess_board: ChessBoard::new(),
        }
    }
}